package com.example.mongobackend.dto;

import lombok.Data;
import lombok.Builder;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;

import jakarta.validation.constraints.*;
import java.time.Instant;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class UserDTO {

    private String id;

    @NotBlank(message = "Employee ID is required")
    @Pattern(regexp = "^[A-Z0-9]+$", message = "Employee ID must be alphanumeric uppercase")
    private String employeeId;

    @NotBlank(message = "Name is required")
    @Size(min = 2, max = 100)
    private String name;

    @NotBlank(message = "Email is required")
    @Email(message = "Invalid email format")
    private String email;

    @NotBlank(message = "Role is required")
    @Pattern(regexp = "^(ADMIN|EMPLOYEE)$", message = "Role must be ADMIN or EMPLOYEE")
    private String role;

    private boolean active;

    private Object createdAt;
    private Instant lastLogin;
    private Instant updatedAt;

    @Size(min = 6, message = "Password must be at least 6 characters")
    private String password;
}